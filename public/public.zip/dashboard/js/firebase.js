// (function() {
//     "use strict";

//     feather.replace();

//     // Graphs
// })();
//  The core Firebase JS SDK is always required and must be listed first

// <!-- TODO: Add SDKs for Firebase products that you want to use
//  https://firebase.google.com/docs/web/setup#available-libraries -->

/* // Your web app's Firebase configuration */

var firebaseConfig = {
    apiKey: "AIzaSyCOR2Jy6OoHIrfZKrrbEWSNQu1qn267JZQ",
    authDomain: "umangapp-43a0d.firebaseapp.com",
    databaseURL: "https://umangapp-43a0d.firebaseio.com",
    projectId: "umangapp-43a0d",
    storageBucket: "umangapp-43a0d.appspot.com",
    messagingSenderId: "72464983253",
    appId: "1:72464983253:web:29afa4a91e1248e3336e5c",
    measurementId: "G-8RP327J159"
};
firebase.initializeApp(firebaseConfig);